# نظام بطاقات المشاهدة (Viewing Cards Management System)

## Overview

This is a bilingual (Arabic RTL) viewing cards management system designed for media content distribution. The application allows administrators to create viewing cards with specific episode allocations and device limits, while users can authenticate with card numbers to access their assigned video content. The system includes episode scheduling, device tracking, real-time status monitoring, and multi-file upload capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- Vanilla JavaScript (no frameworks)
- HTML5 with RTL (Right-to-Left) support for Arabic language
- CSS3 with glass-morphism design pattern
- Native browser APIs (Fetch, EventSource for SSE)

**Design Decisions:**
- **Glass-morphism UI**: Modern aesthetic with backdrop blur effects and semi-transparent cards for visual appeal
- **RTL Layout**: All pages configured for Arabic right-to-left text direction with `dir="rtl"` and `lang="ar"`
- **Client-side Routing**: Simple multi-page application with no SPA framework, prioritizing simplicity
- **Progressive Enhancement**: Core functionality works without JavaScript where possible

**Page Structure:**
1. **User Pages**:
   - `index.html` - Card number login
   - `series.html` - Episode listing with posters
   - `watch.html` - Video player
   - `schedule.html` - Public episode schedule (no authentication required)

2. **Admin Pages** (separate `/admin` directory):
   - `login.html` - Admin authentication
   - `index.html` - Card management dashboard
   - `create-card.html` - Card creation with multi-upload
   - `schedule-manager.html` - Episode schedule editor

**Rationale**: Separation of admin and user interfaces prevents accidental exposure of admin functionality and allows different styling/UX patterns for each audience.

### Backend Architecture

**Technology Stack:**
- PHP backend (implied by `.php` API endpoints)
- JSON-based data storage
- Server-Sent Events (SSE) for real-time updates

**API Design Pattern:**
- RESTful-style endpoints with descriptive names
- JSON request/response format
- Session-based authentication (separate for users and admins)

**Key API Endpoints:**
1. **Authentication**:
   - `/api/verify-card.php` - User card validation
   - `/api/admin-login.php` - Admin authentication

2. **Card Management**:
   - `/api/create-card.php` - Create new viewing card
   - `/api/get-cards.php` - List all cards (admin)
   - `/api/update-card-status.php` - Toggle active/suspended status

3. **Content Delivery**:
   - `/api/get-episodes.php` - Fetch card-specific episodes
   - `/api/schedule-api.php` - Public schedule data

4. **Real-time Monitoring**:
   - `/api/status-stream.php` - SSE endpoint for card status changes

**Design Decisions:**

**Server-Sent Events for Status Monitoring:**
- **Problem**: Need to automatically logout users when their card is suspended
- **Solution**: SSE connection (`EventSource`) maintains persistent connection to monitor card status
- **Rationale**: More efficient than polling, provides instant updates, and simpler than WebSocket implementation
- **Implementation**: `series.js` opens SSE connection on page load; server pushes status updates; client redirects on suspension

**Session-based Authentication:**
- **Problem**: Need to maintain user identity across requests without complex token management
- **Solution**: PHP sessions with separate namespaces for users and admins
- **Pros**: Built-in to PHP, stateful tracking of device connections
- **Cons**: Not suitable for distributed systems (but appropriate for single-server deployment)

### Data Storage

**File-based JSON Storage:**
- `data/cards.json` - Card records
- `data/devices.json` - Connected device tracking
- `data/schedule.json` - Episode release schedule
- `data/series_data.json` - Series metadata

**Upload Storage:**
- `/uploads/episodes/` - Video files
- `/uploads/posters/` - Episode poster images

**Design Decisions:**

**JSON File Storage vs. Database:**
- **Problem**: Need persistent data storage for cards, episodes, and schedules
- **Solution**: JSON files with read/write operations
- **Rationale**: Simplifies deployment (no database server required), suitable for small-to-medium scale operations
- **Pros**: Zero configuration, easy backup, version control friendly
- **Cons**: No ACID guarantees, potential race conditions, not suitable for high-concurrency scenarios
- **Alternative Considered**: SQLite for embedded database benefits while maintaining simplicity

**File-based Upload Storage:**
- **Problem**: Need to store video files and images
- **Solution**: Direct filesystem storage in `/uploads` directory
- **Rationale**: Simple, efficient for media files, works well with web server static file serving
- **Security Note**: Requires access control to prevent unauthorized downloads

### Key Features & Implementation

**Flexible Card Number Length:**
- System accepts card numbers of any length (not fixed to 12 digits)
- Validation focuses on uniqueness rather than format

**Device Limit Enforcement:**
- Tracks device connections per card using device fingerprinting or session IDs
- Prevents login when max device count reached
- Stored in `devices.json` with card association

**Multi-file Upload System:**
- Drag-and-drop interface in `create-card.html`
- Supports batch upload of episodes and posters
- Client-side file preview before upload
- Upload progress tracking (implied by UI requirements)

**Card-Episode Association:**
- Each card has dedicated episodes (not shared across cards)
- Episodes linked to card ID during creation
- Upload limit enforced by `episodeCount` field

**Download Capability:**
- Download button alongside watch button for each episode
- Allows offline viewing within access permissions

**Public Schedule Page:**
- No authentication required for viewing release schedule
- Accessible to promote content and inform potential customers
- Admin-editable through schedule manager

**Automatic Status-based Logout:**
- Real-time monitoring using SSE
- Immediately disconnects suspended users
- Prevents continued viewing when card is deactivated

## External Dependencies

### Third-party Services
- None identified (self-hosted solution)

### External Libraries
- None (vanilla JavaScript implementation)

### File Upload Requirements
- PHP file upload configuration required (`php.ini` settings for max file size)
- Server must handle large video files (appropriate timeout and memory limits)

### Media Serving
- Web server (Apache/Nginx) configured to serve static files from `/uploads` directory
- MIME type configuration for video playback
- Range request support recommended for video seeking

### Browser Requirements
- Modern browser with HTML5 video support
- EventSource API for real-time status monitoring
- Drag and drop API for file uploads
- Fetch API for AJAX requests

### Server Requirements
- PHP 7.0+ (implied by modern syntax)
- Write permissions for `/data` and `/uploads` directories
- Session storage configuration
- Sufficient disk space for video storage

### Security Considerations
- Access control needed for `/uploads` directory (prevent direct URL access without authentication)
- CSRF protection for admin actions
- Input validation for card numbers and file uploads
- Session hijacking protection
- Admin interface should be protected at network level or with IP whitelisting
let eventSource;

function initStatusMonitoring() {
    eventSource = new EventSource('/api/status-stream.php');
    
    eventSource.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        if (!data.active) {
            eventSource.close();
            alert('تم تعليق البطاقة. سيتم تسجيل الخروج الآن.');
            window.location.href = 'index.html';
        }
    };
    
    eventSource.onerror = function(error) {
        console.error('Status monitoring error:', error);
        eventSource.close();
    };
}

async function loadEpisodes() {
    const messageDiv = document.getElementById('message');
    const container = document.getElementById('episodesContainer');
    const cardInfo = document.getElementById('cardInfo');
    
    try {
        const response = await fetch('/api/get-episodes.php');
        const data = await response.json();
        
        if (!data.success) {
            messageDiv.innerHTML = `<div class="message error">${data.message}</div>`;
            setTimeout(() => window.location.href = 'index.html', 2000);
            return;
        }
        
        cardInfo.innerHTML = `<h3>البطاقة: ${data.cardNumber}</h3>`;
        
        if (data.episodes.length === 0) {
            container.innerHTML = '<div style="color: white; text-align: center;">لا توجد حلقات متاحة حالياً</div>';
            return;
        }
        
        container.innerHTML = data.episodes.map(episode => `
            <div class="episode-card">
                ${episode.poster ? 
                    `<img src="/uploads/posters/${episode.poster}" alt="${episode.title}" class="episode-poster">` :
                    '<div class="episode-poster" style="background: rgba(255,255,255,0.1); display: flex; align-items: center; justify-content: center; color: white;">📺</div>'
                }
                <h3 class="episode-title">${episode.title}</h3>
                <div class="episode-actions">
                    <button onclick="watchEpisode('${episode.id}')" class="btn btn-success">مشاهدة</button>
                    <a href="/uploads/episodes/${episode.filename}" download class="btn btn-primary" style="text-decoration: none; text-align: center;">تحميل</a>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        messageDiv.innerHTML = '<div class="message error">حدث خطأ في تحميل الحلقات</div>';
    }
}

function watchEpisode(episodeId) {
    window.location.href = `watch.html?id=${episodeId}`;
}

function logout() {
    if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
        if (eventSource) {
            eventSource.close();
        }
        fetch('/api/logout.php')
            .then(() => window.location.href = 'index.html');
    }
}

initStatusMonitoring();
loadEpisodes();

let currentCardId = null;
let selectedFiles = { episodes: [], posters: [] };

const urlParams = new URLSearchParams(window.location.search);
currentCardId = urlParams.get('id');

if (!currentCardId) {
    window.location.href = 'index.html';
}

async function loadCardDetails() {
    try {
        const response = await fetch(`/api/get-card-details.php?cardId=${currentCardId}`);
        const data = await response.json();
        
        if (!data.success) {
            document.getElementById('message').innerHTML = `<div class="message error">${data.message}</div>`;
            setTimeout(() => window.location.href = 'index.html', 2000);
            return;
        }
        
        const card = data.card;
        
        document.getElementById('cardNumber').value = card.cardNumber;
        document.getElementById('episodeCount').value = card.episodeCount;
        document.getElementById('maxDevices').value = card.maxDevices;
        
        document.getElementById('cardInfo').innerHTML = `
            <h3>البطاقة: ${card.cardNumber}</h3>
            <p>تاريخ الإنشاء: ${card.createdAt}</p>
        `;
        
        document.getElementById('editCardForm').style.display = 'block';
        document.getElementById('uploadSection').style.display = 'block';
        
        displayExistingEpisodes(card.episodes || []);
        
    } catch (error) {
        document.getElementById('message').innerHTML = '<div class="message error">حدث خطأ في تحميل البطاقة</div>';
    }
}

function displayExistingEpisodes(episodes) {
    const container = document.getElementById('existingEpisodes');
    
    if (episodes.length === 0) {
        container.innerHTML = '<div style="color: white; text-align: center;">لا توجد حلقات مرفوعة</div>';
        return;
    }
    
    container.innerHTML = episodes.map(episode => `
        <div class="episode-card">
            ${episode.poster ? 
                `<img src="/uploads/posters/${episode.poster}" alt="${episode.title}" class="episode-poster">` :
                '<div class="episode-poster" style="background: rgba(255,255,255,0.1); display: flex; align-items: center; justify-content: center; color: white;">📺</div>'
            }
            <h3 class="episode-title">${episode.title}</h3>
            <p style="color: rgba(255,255,255,0.7); font-size: 0.9em;">${episode.filename}</p>
        </div>
    `).join('');
}

document.getElementById('editCardForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const episodeCount = parseInt(document.getElementById('episodeCount').value);
    const maxDevices = parseInt(document.getElementById('maxDevices').value);
    const messageDiv = document.getElementById('message');
    
    try {
        const response = await fetch('/api/update-card.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cardId: currentCardId, episodeCount, maxDevices })
        });
        
        const data = await response.json();
        
        if (data.success) {
            messageDiv.innerHTML = '<div class="message success">تم تحديث البطاقة بنجاح!</div>';
            setTimeout(() => messageDiv.innerHTML = '', 3000);
        } else {
            messageDiv.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message error">حدث خطأ في تحديث البطاقة</div>';
    }
});

const videoUploadArea = document.getElementById('videoUploadArea');
const videoInput = document.getElementById('videoInput');
const posterUploadArea = document.getElementById('posterUploadArea');
const posterInput = document.getElementById('posterInput');

videoUploadArea.addEventListener('click', () => videoInput.click());
posterUploadArea.addEventListener('click', () => posterInput.click());

videoUploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    videoUploadArea.classList.add('dragover');
});

videoUploadArea.addEventListener('dragleave', () => {
    videoUploadArea.classList.remove('dragover');
});

videoUploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    videoUploadArea.classList.remove('dragover');
    handleVideoFiles(e.dataTransfer.files);
});

posterUploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    posterUploadArea.classList.add('dragover');
});

posterUploadArea.addEventListener('dragleave', () => {
    posterUploadArea.classList.remove('dragover');
});

posterUploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    posterUploadArea.classList.remove('dragover');
    handlePosterFiles(e.dataTransfer.files);
});

videoInput.addEventListener('change', (e) => {
    handleVideoFiles(e.target.files);
});

posterInput.addEventListener('change', (e) => {
    handlePosterFiles(e.target.files);
});

function handleVideoFiles(files) {
    const videoList = document.getElementById('videoList');
    selectedFiles.episodes = [];
    videoList.innerHTML = '';
    
    Array.from(files).forEach(file => {
        if (file.type.startsWith('video/')) {
            selectedFiles.episodes.push(file);
            
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.innerHTML = `
                <span>🎬 ${file.name}</span>
                <span>${(file.size / 1024 / 1024).toFixed(2)} MB</span>
            `;
            videoList.appendChild(fileItem);
        }
    });
    
    updateUploadButton();
}

function handlePosterFiles(files) {
    const posterList = document.getElementById('posterList');
    selectedFiles.posters = [];
    posterList.innerHTML = '';
    
    Array.from(files).forEach(file => {
        if (file.type.startsWith('image/')) {
            selectedFiles.posters.push(file);
            
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.innerHTML = `
                <span>🖼️ ${file.name}</span>
                <span>${(file.size / 1024 / 1024).toFixed(2)} MB</span>
            `;
            posterList.appendChild(fileItem);
        }
    });
    
    updateUploadButton();
}

function updateUploadButton() {
    const uploadBtn = document.getElementById('uploadBtn');
    if (selectedFiles.episodes.length > 0 || selectedFiles.posters.length > 0) {
        uploadBtn.style.display = 'block';
    } else {
        uploadBtn.style.display = 'none';
    }
}

document.getElementById('uploadBtn').addEventListener('click', async () => {
    const messageDiv = document.getElementById('message');
    const formData = new FormData();
    
    formData.append('cardId', currentCardId);
    
    selectedFiles.episodes.forEach(file => {
        formData.append('episodes[]', file);
    });
    
    selectedFiles.posters.forEach(file => {
        formData.append('posters[]', file);
    });
    
    try {
        messageDiv.innerHTML = '<div class="message success">جاري رفع الملفات...</div>';
        
        const response = await fetch('/api/upload-episodes.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            messageDiv.innerHTML = `<div class="message success">تم رفع ${data.uploadedCount} حلقة بنجاح!</div>';
            setTimeout(() => {
                location.reload();
            }, 2000);
        } else {
            messageDiv.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message error">حدث خطأ في رفع الملفات</div>';
    }
});

loadCardDetails();

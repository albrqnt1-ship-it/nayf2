async function loadEpisode() {
    const urlParams = new URLSearchParams(window.location.search);
    const episodeId = urlParams.get('id');
    
    if (!episodeId) {
        window.location.href = 'series.html';
        return;
    }
    
    try {
        const response = await fetch('/api/get-episodes.php');
        const data = await response.json();
        
        if (!data.success) {
            window.location.href = 'index.html';
            return;
        }
        
        const episode = data.episodes.find(ep => ep.id === episodeId);
        
        if (!episode) {
            alert('الحلقة غير موجودة');
            window.location.href = 'series.html';
            return;
        }
        
        document.getElementById('episodeTitle').textContent = episode.title;
        document.getElementById('videoContainer').innerHTML = `
            <video controls autoplay>
                <source src="/uploads/episodes/${episode.filename}" type="video/mp4">
                المتصفح لا يدعم تشغيل الفيديو
            </video>
        `;
        
    } catch (error) {
        alert('حدث خطأ في تحميل الحلقة');
        window.location.href = 'series.html';
    }
}

loadEpisode();

let currentCardId = null;
let selectedFiles = { episodes: [], posters: [] };

document.getElementById('createCardForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const cardNumber = document.getElementById('cardNumber').value.trim();
    const episodeCount = parseInt(document.getElementById('episodeCount').value);
    const maxDevices = parseInt(document.getElementById('maxDevices').value);
    const messageDiv = document.getElementById('message');
    
    try {
        const response = await fetch('/api/create-card.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cardNumber, episodeCount, maxDevices })
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentCardId = data.card.id;
            messageDiv.innerHTML = '<div class="message success">تم إنشاء البطاقة بنجاح! يمكنك الآن رفع الحلقات</div>';
            document.getElementById('uploadSection').style.display = 'block';
            document.getElementById('createCardForm').style.display = 'none';
        } else {
            messageDiv.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message error">حدث خطأ في إنشاء البطاقة</div>';
    }
});

const videoUploadArea = document.getElementById('videoUploadArea');
const videoInput = document.getElementById('videoInput');
const posterUploadArea = document.getElementById('posterUploadArea');
const posterInput = document.getElementById('posterInput');

videoUploadArea.addEventListener('click', () => videoInput.click());
posterUploadArea.addEventListener('click', () => posterInput.click());

videoUploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    videoUploadArea.classList.add('dragover');
});

videoUploadArea.addEventListener('dragleave', () => {
    videoUploadArea.classList.remove('dragover');
});

videoUploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    videoUploadArea.classList.remove('dragover');
    handleVideoFiles(e.dataTransfer.files);
});

posterUploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    posterUploadArea.classList.add('dragover');
});

posterUploadArea.addEventListener('dragleave', () => {
    posterUploadArea.classList.remove('dragover');
});

posterUploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    posterUploadArea.classList.remove('dragover');
    handlePosterFiles(e.dataTransfer.files);
});

videoInput.addEventListener('change', (e) => {
    handleVideoFiles(e.target.files);
});

posterInput.addEventListener('change', (e) => {
    handlePosterFiles(e.target.files);
});

function handleVideoFiles(files) {
    const videoList = document.getElementById('videoList');
    selectedFiles.episodes = [];
    videoList.innerHTML = '';
    
    Array.from(files).forEach(file => {
        if (file.type.startsWith('video/')) {
            selectedFiles.episodes.push(file);
            
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.innerHTML = `
                <span>🎬 ${file.name}</span>
                <span>${(file.size / 1024 / 1024).toFixed(2)} MB</span>
            `;
            videoList.appendChild(fileItem);
        }
    });
    
    updateUploadButton();
}

function handlePosterFiles(files) {
    const posterList = document.getElementById('posterList');
    selectedFiles.posters = [];
    posterList.innerHTML = '';
    
    Array.from(files).forEach(file => {
        if (file.type.startsWith('image/')) {
            selectedFiles.posters.push(file);
            
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.innerHTML = `
                <span>🖼️ ${file.name}</span>
                <span>${(file.size / 1024 / 1024).toFixed(2)} MB</span>
            `;
            posterList.appendChild(fileItem);
        }
    });
    
    updateUploadButton();
}

function updateUploadButton() {
    const uploadBtn = document.getElementById('uploadBtn');
    if (selectedFiles.episodes.length > 0 || selectedFiles.posters.length > 0) {
        uploadBtn.style.display = 'block';
    } else {
        uploadBtn.style.display = 'none';
    }
}

document.getElementById('uploadBtn').addEventListener('click', async () => {
    if (!currentCardId) {
        alert('خطأ: لم يتم إنشاء البطاقة');
        return;
    }
    
    const messageDiv = document.getElementById('message');
    const formData = new FormData();
    
    formData.append('cardId', currentCardId);
    
    selectedFiles.episodes.forEach(file => {
        formData.append('episodes[]', file);
    });
    
    selectedFiles.posters.forEach(file => {
        formData.append('posters[]', file);
    });
    
    try {
        messageDiv.innerHTML = '<div class="message success">جاري رفع الملفات...</div>';
        
        const response = await fetch('/api/upload-episodes.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            messageDiv.innerHTML = `<div class="message success">تم رفع ${data.uploadedCount} حلقة بنجاح!</div>`;
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 2000);
        } else {
            messageDiv.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message error">حدث خطأ في رفع الملفات</div>';
    }
});

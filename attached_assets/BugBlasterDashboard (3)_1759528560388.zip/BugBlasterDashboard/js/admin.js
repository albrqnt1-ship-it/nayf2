async function loadCards() {
    try {
        const response = await fetch('/api/get-cards.php');
        const data = await response.json();
        
        if (!data.success) {
            if (response.status === 401) {
                window.location.href = 'login.html';
                return;
            }
            document.getElementById('message').innerHTML = `<div class="message error">${data.message}</div>`;
            return;
        }
        
        const tbody = document.getElementById('cardsTableBody');
        
        if (data.cards.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">لا توجد بطاقات</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.cards.map(card => `
            <tr>
                <td>${card.cardNumber}</td>
                <td>${card.uploadedEpisodes} / ${card.episodeCount}</td>
                <td>${card.connectedDevices} / ${card.maxDevices}</td>
                <td><span class="status-badge status-${card.status}">${card.status === 'active' ? 'نشط' : 'معلق'}</span></td>
                <td>${card.createdAt}</td>
                <td>
                    <a href="edit-card.html?id=${card.id}" class="btn btn-primary" style="margin: 5px; padding: 8px 15px; text-decoration: none; display: inline-block;">تعديل</a>
                    <button onclick="toggleStatus('${card.id}', '${card.status}')" class="btn ${card.status === 'active' ? 'btn-danger' : 'btn-success'}" style="margin: 5px; padding: 8px 15px;">
                        ${card.status === 'active' ? 'تعليق' : 'تفعيل'}
                    </button>
                    <button onclick="deleteCard('${card.id}')" class="btn btn-danger" style="padding: 8px 15px;">حذف</button>
                </td>
            </tr>
        `).join('');
        
    } catch (error) {
        document.getElementById('message').innerHTML = '<div class="message error">حدث خطأ في تحميل البطاقات</div>';
    }
}

async function toggleStatus(cardId, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'suspended' : 'active';
    
    try {
        const response = await fetch('/api/update-card-status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cardId, status: newStatus })
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadCards();
            document.getElementById('message').innerHTML = '<div class="message success">تم تحديث الحالة بنجاح</div>';
            setTimeout(() => document.getElementById('message').innerHTML = '', 3000);
        } else {
            document.getElementById('message').innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        document.getElementById('message').innerHTML = '<div class="message error">حدث خطأ</div>';
    }
}

async function deleteCard(cardId) {
    if (!confirm('هل أنت متأكد من حذف هذه البطاقة؟ سيتم حذف جميع الحلقات المرتبطة بها.')) {
        return;
    }
    
    try {
        const response = await fetch('/api/delete-card.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cardId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadCards();
            document.getElementById('message').innerHTML = '<div class="message success">تم حذف البطاقة بنجاح</div>';
            setTimeout(() => document.getElementById('message').innerHTML = '', 3000);
        } else {
            document.getElementById('message').innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        document.getElementById('message').innerHTML = '<div class="message error">حدث خطأ</div>';
    }
}

function adminLogout() {
    if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
        fetch('/api/logout.php')
            .then(() => window.location.href = 'login.html');
    }
}

loadCards();

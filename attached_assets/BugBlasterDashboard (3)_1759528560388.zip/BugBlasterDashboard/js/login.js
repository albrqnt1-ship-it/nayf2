document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const cardNumber = document.getElementById('cardNumber').value.trim();
    const messageDiv = document.getElementById('message');
    
    try {
        const response = await fetch('/api/verify-card.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cardNumber })
        });
        
        const data = await response.json();
        
        if (data.success) {
            messageDiv.innerHTML = '<div class="message success">جاري التحويل...</div>';
            setTimeout(() => {
                window.location.href = 'series.html';
            }, 1000);
        } else {
            messageDiv.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message error">حدث خطأ في الاتصال</div>';
    }
});

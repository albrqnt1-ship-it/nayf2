async function loadSchedule() {
    const container = document.getElementById('scheduleContainer');
    
    try {
        const response = await fetch('/api/schedule-api.php');
        const data = await response.json();
        
        if (!data.success) {
            container.innerHTML = '<div style="color: white; text-align: center;">حدث خطأ في تحميل الجدول</div>';
            return;
        }
        
        container.innerHTML = data.schedule.map(day => `
            <div class="day-card">
                <h2 class="day-title">${day.day}</h2>
                ${day.episodes && day.episodes.length > 0 ? 
                    day.episodes.map(ep => `
                        <div class="episode-item">
                            <strong>${ep.name || 'حلقة'}</strong> - ${ep.time || 'الوقت غير محدد'}
                        </div>
                    `).join('') :
                    '<div style="color: rgba(255,255,255,0.6); text-align: center;">لا توجد حلقات</div>'
                }
            </div>
        `).join('');
        
    } catch (error) {
        container.innerHTML = '<div style="color: white; text-align: center;">حدث خطأ في تحميل الجدول</div>';
    }
}

loadSchedule();

let scheduleData = [];

async function loadSchedule() {
    try {
        const response = await fetch('/api/schedule-api.php');
        const data = await response.json();
        
        if (data.success) {
            scheduleData = data.schedule;
            renderScheduleEditor();
        }
    } catch (error) {
        document.getElementById('message').innerHTML = '<div class="message error">حدث خطأ في تحميل الجدول</div>';
    }
}

function renderScheduleEditor() {
    const container = document.getElementById('scheduleEditor');
    
    container.innerHTML = scheduleData.map((day, dayIndex) => `
        <div class="day-card">
            <h2 class="day-title">${day.day}</h2>
            <div id="day-${dayIndex}-episodes">
                ${(day.episodes || []).map((ep, epIndex) => `
                    <div class="episode-item" style="display: flex; gap: 10px; align-items: center;">
                        <input type="text" value="${ep.name || ''}" placeholder="اسم الحلقة" 
                               onchange="updateEpisode(${dayIndex}, ${epIndex}, 'name', this.value)"
                               style="flex: 1; padding: 10px; border-radius: 5px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.1); color: white;">
                        <input type="text" value="${ep.time || ''}" placeholder="الوقت" 
                               onchange="updateEpisode(${dayIndex}, ${epIndex}, 'time', this.value)"
                               style="width: 150px; padding: 10px; border-radius: 5px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.1); color: white;">
                        <button onclick="removeEpisode(${dayIndex}, ${epIndex})" class="btn btn-danger" style="padding: 10px 15px;">حذف</button>
                    </div>
                `).join('')}
            </div>
            <button onclick="addEpisode(${dayIndex})" class="btn btn-success" style="margin-top: 10px;">إضافة حلقة</button>
        </div>
    `).join('');
}

function updateEpisode(dayIndex, epIndex, field, value) {
    if (!scheduleData[dayIndex].episodes) {
        scheduleData[dayIndex].episodes = [];
    }
    scheduleData[dayIndex].episodes[epIndex][field] = value;
}

function addEpisode(dayIndex) {
    if (!scheduleData[dayIndex].episodes) {
        scheduleData[dayIndex].episodes = [];
    }
    scheduleData[dayIndex].episodes.push({ name: '', time: '' });
    renderScheduleEditor();
}

function removeEpisode(dayIndex, epIndex) {
    scheduleData[dayIndex].episodes.splice(epIndex, 1);
    renderScheduleEditor();
}

document.getElementById('saveScheduleBtn').addEventListener('click', async () => {
    const messageDiv = document.getElementById('message');
    
    try {
        const response = await fetch('/api/schedule-api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ schedule: scheduleData })
        });
        
        const data = await response.json();
        
        if (data.success) {
            messageDiv.innerHTML = '<div class="message success">تم حفظ الجدول بنجاح</div>';
            setTimeout(() => messageDiv.innerHTML = '', 3000);
        } else {
            messageDiv.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message error">حدث خطأ في حفظ الجدول</div>';
    }
});

loadSchedule();

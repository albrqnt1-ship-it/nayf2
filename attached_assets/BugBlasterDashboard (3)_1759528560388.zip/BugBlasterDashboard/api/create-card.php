<?php
require_once 'config.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة غير مسموحة']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$cardNumber = sanitizeInput($input['cardNumber'] ?? '');
$episodeCount = intval($input['episodeCount'] ?? 0);
$maxDevices = intval($input['maxDevices'] ?? 1);

if (empty($cardNumber) || $episodeCount <= 0 || $maxDevices <= 0) {
    echo json_encode(['success' => false, 'message' => 'البيانات غير صحيحة']);
    exit;
}

$cards = getJsonData('cards.json');

foreach ($cards as $card) {
    if ($card['cardNumber'] === $cardNumber) {
        echo json_encode(['success' => false, 'message' => 'رقم البطاقة موجود مسبقاً']);
        exit;
    }
}

$newCard = [
    'id' => generateId(),
    'cardNumber' => $cardNumber,
    'episodeCount' => $episodeCount,
    'maxDevices' => $maxDevices,
    'status' => 'active',
    'episodes' => [],
    'createdAt' => date('Y-m-d H:i:s')
];

$cards[] = $newCard;
saveJsonData('cards.json', $cards);

echo json_encode([
    'success' => true,
    'message' => 'تم إنشاء البطاقة بنجاح',
    'card' => $newCard
]);

<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $schedule = getJsonData('schedule.json');
    echo json_encode(['success' => true, 'schedule' => $schedule['schedule'] ?? []]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAdmin();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $schedule = $input['schedule'] ?? [];
    
    saveJsonData('schedule.json', ['schedule' => $schedule]);
    echo json_encode(['success' => true, 'message' => 'تم تحديث الجدول بنجاح']);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'طريقة غير مسموحة']);

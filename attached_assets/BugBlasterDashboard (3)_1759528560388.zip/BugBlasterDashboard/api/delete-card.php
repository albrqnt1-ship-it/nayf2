<?php
require_once 'config.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة غير مسموحة']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$cardId = sanitizeInput($input['cardId'] ?? '');

if (empty($cardId)) {
    echo json_encode(['success' => false, 'message' => 'معرف البطاقة مطلوب']);
    exit;
}

$cards = getJsonData('cards.json');
$cardIndex = -1;

foreach ($cards as $index => $card) {
    if ($card['id'] === $cardId) {
        $cardIndex = $index;
        break;
    }
}

if ($cardIndex === -1) {
    echo json_encode(['success' => false, 'message' => 'البطاقة غير موجودة']);
    exit;
}

$card = $cards[$cardIndex];

foreach ($card['episodes'] as $episode) {
    if (!empty($episode['filename'])) {
        $episodePath = UPLOAD_DIR . 'episodes/' . $episode['filename'];
        if (file_exists($episodePath)) {
            unlink($episodePath);
        }
    }
    if (!empty($episode['poster'])) {
        $posterPath = UPLOAD_DIR . 'posters/' . $episode['poster'];
        if (file_exists($posterPath)) {
            unlink($posterPath);
        }
    }
}

$devices = getJsonData('devices.json');
$devices = array_filter($devices, function($d) use ($cardId) {
    return $d['cardId'] !== $cardId;
});
saveJsonData('devices.json', array_values($devices));

array_splice($cards, $cardIndex, 1);
saveJsonData('cards.json', $cards);

echo json_encode(['success' => true, 'message' => 'تم حذف البطاقة بنجاح']);

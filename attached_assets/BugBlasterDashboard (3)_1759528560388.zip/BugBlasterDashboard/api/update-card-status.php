<?php
require_once 'config.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة غير مسموحة']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$cardId = sanitizeInput($input['cardId'] ?? '');
$status = sanitizeInput($input['status'] ?? '');

if (empty($cardId) || !in_array($status, ['active', 'suspended'])) {
    echo json_encode(['success' => false, 'message' => 'البيانات غير صحيحة']);
    exit;
}

$cards = getJsonData('cards.json');

foreach ($cards as &$card) {
    if ($card['id'] === $cardId) {
        $card['status'] = $status;
        saveJsonData('cards.json', $cards);
        echo json_encode(['success' => true, 'message' => 'تم تحديث حالة البطاقة']);
        exit;
    }
}

echo json_encode(['success' => false, 'message' => 'البطاقة غير موجودة']);

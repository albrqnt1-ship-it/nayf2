<?php
require_once 'config.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة غير مسموحة']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$cardId = sanitizeInput($input['cardId'] ?? '');
$episodeCount = intval($input['episodeCount'] ?? 0);
$maxDevices = intval($input['maxDevices'] ?? 1);

if (empty($cardId) || $episodeCount <= 0 || $maxDevices <= 0) {
    echo json_encode(['success' => false, 'message' => 'البيانات غير صحيحة']);
    exit;
}

$cards = getJsonData('cards.json');
$cardIndex = -1;

foreach ($cards as $index => $card) {
    if ($card['id'] === $cardId) {
        $cardIndex = $index;
        break;
    }
}

if ($cardIndex === -1) {
    echo json_encode(['success' => false, 'message' => 'البطاقة غير موجودة']);
    exit;
}

$cards[$cardIndex]['episodeCount'] = $episodeCount;
$cards[$cardIndex]['maxDevices'] = $maxDevices;

saveJsonData('cards.json', $cards);

echo json_encode([
    'success' => true,
    'message' => 'تم تحديث البطاقة بنجاح',
    'card' => $cards[$cardIndex]
]);

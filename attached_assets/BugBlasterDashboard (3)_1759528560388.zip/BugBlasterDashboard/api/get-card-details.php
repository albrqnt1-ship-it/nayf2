<?php
require_once 'config.php';
requireAdmin();

if (!isset($_GET['cardId'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'معرف البطاقة مطلوب']);
    exit;
}

$cardId = sanitizeInput($_GET['cardId']);
$cards = getJsonData('cards.json');
$card = null;

foreach ($cards as $c) {
    if ($c['id'] === $cardId) {
        $card = $c;
        break;
    }
}

if (!$card) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'البطاقة غير موجودة']);
    exit;
}

echo json_encode(['success' => true, 'card' => $card]);

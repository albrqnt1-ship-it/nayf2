<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة غير مسموحة']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$cardNumber = sanitizeInput($input['cardNumber'] ?? '');

if (empty($cardNumber)) {
    echo json_encode(['success' => false, 'message' => 'رقم البطاقة مطلوب']);
    exit;
}

$cards = getJsonData('cards.json');
$card = null;

foreach ($cards as $c) {
    if ($c['cardNumber'] === $cardNumber) {
        $card = $c;
        break;
    }
}

if (!$card) {
    echo json_encode(['success' => false, 'message' => 'رقم البطاقة غير صحيح']);
    exit;
}

if ($card['status'] !== 'active') {
    echo json_encode(['success' => false, 'message' => 'البطاقة معلقة']);
    exit;
}

$devices = getJsonData('devices.json');
$fingerprint = getClientFingerprint();
$cardDevices = array_filter($devices, function($d) use ($card) {
    return $d['cardId'] === $card['id'];
});

$deviceExists = false;
foreach ($cardDevices as $device) {
    if ($device['fingerprint'] === $fingerprint) {
        $deviceExists = true;
        break;
    }
}

if (!$deviceExists) {
    if (count($cardDevices) >= $card['maxDevices']) {
        echo json_encode(['success' => false, 'message' => 'تم تجاوز عدد الأجهزة المسموح بها']);
        exit;
    }
    
    $devices[] = [
        'id' => generateId(),
        'cardId' => $card['id'],
        'fingerprint' => $fingerprint,
        'connectedAt' => date('Y-m-d H:i:s')
    ];
    saveJsonData('devices.json', $devices);
}

$_SESSION['card_id'] = $card['id'];
$_SESSION['card_number'] = $card['cardNumber'];

echo json_encode([
    'success' => true,
    'message' => 'تم التحقق بنجاح',
    'card' => [
        'id' => $card['id'],
        'cardNumber' => $card['cardNumber'],
        'episodeCount' => $card['episodeCount']
    ]
]);

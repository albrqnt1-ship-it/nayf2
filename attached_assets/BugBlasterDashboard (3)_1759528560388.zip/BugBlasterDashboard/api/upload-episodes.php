<?php
require_once 'config.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة غير مسموحة']);
    exit;
}

$cardId = sanitizeInput($_POST['cardId'] ?? '');

if (empty($cardId)) {
    echo json_encode(['success' => false, 'message' => 'معرف البطاقة مطلوب']);
    exit;
}

$cards = getJsonData('cards.json');
$cardIndex = -1;

foreach ($cards as $index => $card) {
    if ($card['id'] === $cardId) {
        $cardIndex = $index;
        break;
    }
}

if ($cardIndex === -1) {
    echo json_encode(['success' => false, 'message' => 'البطاقة غير موجودة']);
    exit;
}

$card = &$cards[$cardIndex];
$allowedVideos = ['mp4', 'mkv', 'avi', 'mov', 'webm'];
$allowedImages = ['jpg', 'jpeg', 'png', 'webp'];

$uploadedEpisodes = [];

if (isset($_FILES['episodes'])) {
    $episodesDir = UPLOAD_DIR . 'episodes/';
    if (!is_dir($episodesDir)) {
        mkdir($episodesDir, 0755, true);
    }

    $files = $_FILES['episodes'];
    $fileCount = is_array($files['name']) ? count($files['name']) : 1;
    
    for ($i = 0; $i < $fileCount; $i++) {
        $fileName = is_array($files['name']) ? $files['name'][$i] : $files['name'];
        $fileTmpName = is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'];
        $fileSize = is_array($files['size']) ? $files['size'][$i] : $files['size'];
        
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowedVideos)) {
            continue;
        }
        
        $newFileName = $cardId . '_' . generateId() . '.' . $ext;
        $destination = $episodesDir . $newFileName;
        
        if (move_uploaded_file($fileTmpName, $destination)) {
            $uploadedEpisodes[] = [
                'id' => generateId(),
                'title' => pathinfo($fileName, PATHINFO_FILENAME),
                'filename' => $newFileName,
                'poster' => '',
                'uploadedAt' => date('Y-m-d H:i:s')
            ];
        }
    }
}

if (isset($_FILES['posters'])) {
    $postersDir = UPLOAD_DIR . 'posters/';
    if (!is_dir($postersDir)) {
        mkdir($postersDir, 0755, true);
    }

    $files = $_FILES['posters'];
    $fileCount = is_array($files['name']) ? count($files['name']) : 1;
    
    for ($i = 0; $i < min($fileCount, count($uploadedEpisodes)); $i++) {
        $fileName = is_array($files['name']) ? $files['name'][$i] : $files['name'];
        $fileTmpName = is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'];
        
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowedImages)) {
            continue;
        }
        
        $newFileName = $cardId . '_poster_' . $i . '.' . $ext;
        $destination = $postersDir . $newFileName;
        
        if (move_uploaded_file($fileTmpName, $destination)) {
            $uploadedEpisodes[$i]['poster'] = $newFileName;
        }
    }
}

$card['episodes'] = array_merge($card['episodes'], $uploadedEpisodes);
saveJsonData('cards.json', $cards);

echo json_encode([
    'success' => true,
    'message' => 'تم رفع الحلقات بنجاح',
    'uploadedCount' => count($uploadedEpisodes)
]);

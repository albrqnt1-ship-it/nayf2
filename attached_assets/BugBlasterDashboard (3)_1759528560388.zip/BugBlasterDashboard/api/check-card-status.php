<?php
require_once 'config.php';

if (!isset($_SESSION['card_id'])) {
    echo json_encode(['success' => false, 'active' => false, 'message' => 'غير مسجل دخول']);
    exit;
}

$cards = getJsonData('cards.json');
$card = null;

foreach ($cards as $c) {
    if ($c['id'] === $_SESSION['card_id']) {
        $card = $c;
        break;
    }
}

if (!$card || $card['status'] !== 'active') {
    session_destroy();
    echo json_encode(['success' => false, 'active' => false, 'message' => 'البطاقة معلقة']);
    exit;
}

echo json_encode(['success' => true, 'active' => true]);

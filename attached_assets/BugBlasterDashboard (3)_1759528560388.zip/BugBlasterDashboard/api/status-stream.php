<?php
require_once 'config.php';

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('X-Accel-Buffering: no');

if (!isset($_SESSION['card_id'])) {
    echo "data: " . json_encode(['active' => false, 'message' => 'غير مسجل دخول']) . "\n\n";
    flush();
    exit;
}

while (true) {
    $cards = getJsonData('cards.json');
    $card = null;
    
    foreach ($cards as $c) {
        if ($c['id'] === $_SESSION['card_id']) {
            $card = $c;
            break;
        }
    }
    
    if (!$card || $card['status'] !== 'active') {
        echo "data: " . json_encode(['active' => false, 'message' => 'البطاقة معلقة']) . "\n\n";
        flush();
        session_destroy();
        break;
    }
    
    echo "data: " . json_encode(['active' => true]) . "\n\n";
    flush();
    
    if (connection_aborted()) {
        break;
    }
    
    sleep(3);
}

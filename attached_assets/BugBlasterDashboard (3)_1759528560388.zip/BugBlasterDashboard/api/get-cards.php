<?php
require_once 'config.php';
requireAdmin();

$cards = getJsonData('cards.json');
$devices = getJsonData('devices.json');

$cardsWithStats = array_map(function($card) use ($devices) {
    $cardDevices = array_filter($devices, function($d) use ($card) {
        return $d['cardId'] === $card['id'];
    });
    
    return [
        'id' => $card['id'],
        'cardNumber' => $card['cardNumber'],
        'episodeCount' => $card['episodeCount'],
        'uploadedEpisodes' => count($card['episodes'] ?? []),
        'maxDevices' => $card['maxDevices'],
        'connectedDevices' => count($cardDevices),
        'status' => $card['status'],
        'createdAt' => $card['createdAt']
    ];
}, $cards);

echo json_encode(['success' => true, 'cards' => $cardsWithStats]);
